#!/bin/bash
# Simple Git updater that excludes itself

SCRIPT_NAME=$(basename "$0")

# Stage all changes except the script itself
git add . ':!'"$SCRIPT_NAME"

# Commit with provided message (default: "Changes")
COMMIT_MSG=${1:-"Changes"}
git commit -m "$COMMIT_MSG"

# Push to main branch
git push https://sevenMDL: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@github.com/sevenMDL/quickbill-desk.git main

echo "✅ Changes pushed to GitHub (script itself excluded)."
